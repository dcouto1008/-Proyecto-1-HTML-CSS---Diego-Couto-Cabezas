# ============================================================
# PROYECTO 3 - KATAS PYTHON
# Autor: Diego Couto Cabezas
# ============================================================

from functools import reduce
import math


# ============================================================
# KATA 1
# Escribe una función que reciba una cadena de texto como
# parámetro y devuelva un diccionario con las frecuencias
# de cada letra. Los espacios no deben ser considerados.
# ============================================================

def frecuencia_letras(cadena):
    frecuencias = {}
    for letra in cadena:
        if letra != " ":
            # Si la letra ya existe en el dict, sumamos 1; si no, la inicializamos a 1
            frecuencias[letra] = frecuencias.get(letra, 0) + 1
    return frecuencias

print("--- Kata 1 ---")
print(frecuencia_letras("hola mundo"))


# ============================================================
# KATA 2
# Dada una lista de números, obtén una nueva lista con el
# doble de cada valor. Usa la función map().
# ============================================================

def doble_lista(numeros):
    return list(map(lambda x: x * 2, numeros))

print("\n--- Kata 2 ---")
print(doble_lista([1, 2, 3, 4, 5]))


# ============================================================
# KATA 3
# Escribe una función que tome una lista de palabras y una
# palabra objetivo. Devuelve las palabras que contengan
# la palabra objetivo.
# ============================================================

def palabras_que_contienen(lista, objetivo):
    return [palabra for palabra in lista if objetivo in palabra]

print("\n--- Kata 3 ---")
print(palabras_que_contienen(["python", "javascript", "java", "typescript"], "java"))


# ============================================================
# KATA 4
# Genera una función que calcule la diferencia entre los
# valores de dos listas. Usa la función map().
# ============================================================

def diferencia_listas(lista1, lista2):
    # map() aplica la función a cada par de elementos de ambas listas
    return list(map(lambda a, b: a - b, lista1, lista2))

print("\n--- Kata 4 ---")
print(diferencia_listas([10, 20, 30], [3, 5, 10]))


# ============================================================
# KATA 5
# Función que calcule la media de una lista y determine si
# es aprobado o suspenso. Devuelve una tupla (media, estado).
# nota_aprobado es 5 por defecto.
# ============================================================

def media_y_estado(numeros, nota_aprobado=5):
    media = sum(numeros) / len(numeros)
    estado = "aprobado" if media >= nota_aprobado else "suspenso"
    return (media, estado)

print("\n--- Kata 5 ---")
print(media_y_estado([4, 6, 7, 3]))
print(media_y_estado([3, 2, 4], nota_aprobado=5))


# ============================================================
# KATA 6
# Escribe una función que calcule el factorial de un número
# de manera recursiva.
# ============================================================

def factorial(n):
    # Caso base: el factorial de 0 o 1 es 1
    if n <= 1:
        return 1
    # Caso recursivo: n * factorial(n-1)
    return n * factorial(n - 1)

print("\n--- Kata 6 ---")
print(factorial(5))
print(factorial(0))


# ============================================================
# KATA 7
# Genera una función que convierta una lista de tuplas a una
# lista de strings. Usa la función map().
# ============================================================

def tuplas_a_strings(lista_tuplas):
    # Convertimos cada tupla a string uniéndola con un guión
    return list(map(lambda t: " - ".join(str(e) for e in t), lista_tuplas))

print("\n--- Kata 7 ---")
print(tuplas_a_strings([("Diego", 25), ("Ana", 30), ("Carlos", 22)]))


# ============================================================
# KATA 8
# Programa que pide dos números e intenta dividirlos.
# Maneja excepciones de valor no numérico y división por cero.
# ============================================================

def dividir_numeros():
    try:
        a = float(input("Introduce el primer número: "))
        b = float(input("Introduce el segundo número: "))
        resultado = a / b
        print(f"División exitosa: {a} / {b} = {resultado}")
    except ValueError:
        print("Error: debes introducir un valor numérico.")
    except ZeroDivisionError:
        print("Error: no se puede dividir por cero.")

print("\n--- Kata 8 ---")
# dividir_numeros()  # Descomenta para ejecutar interactivamente


# ============================================================
# KATA 9
# Función que tome una lista de mascotas y devuelva una nueva
# excluyendo las mascotas prohibidas en España. Usa filter().
# ============================================================

def filtrar_mascotas(mascotas):
    prohibidas = ["Mapache", "Tigre", "Serpiente Pitón", "Cocodrilo", "Oso"]
    return list(filter(lambda m: m not in prohibidas, mascotas))

print("\n--- Kata 9 ---")
print(filtrar_mascotas(["Perro", "Mapache", "Gato", "Tigre", "Conejo"]))


# ============================================================
# KATA 10
# Función que reciba una lista de números y calcule su
# promedio. Si la lista está vacía, lanza una excepción.
# ============================================================

class ListaVaciaError(Exception):
    pass

def promedio_con_excepcion(numeros):
    if len(numeros) == 0:
        raise ListaVaciaError("La lista está vacía, no se puede calcular el promedio.")
    return sum(numeros) / len(numeros)

print("\n--- Kata 10 ---")
try:
    print(promedio_con_excepcion([10, 20, 30]))
    print(promedio_con_excepcion([]))
except ListaVaciaError as e:
    print(f"Error: {e}")


# ============================================================
# KATA 11
# Programa que pide la edad al usuario. Maneja excepciones
# si no es numérico o está fuera del rango 0-120.
# ============================================================

def pedir_edad():
    try:
        edad = int(input("Introduce tu edad: "))
        if edad < 0 or edad > 120:
            raise ValueError("La edad debe estar entre 0 y 120.")
        print(f"Edad válida: {edad}")
    except ValueError as e:
        print(f"Error: {e}")

print("\n--- Kata 11 ---")
# pedir_edad()  # Descomenta para ejecutar interactivamente


# ============================================================
# KATA 12
# Función que, al recibir una frase, devuelva una lista con
# la longitud de cada palabra. Usa la función map().
# ============================================================

def longitud_palabras(frase):
    palabras = frase.split()
    return list(map(len, palabras))

print("\n--- Kata 12 ---")
print(longitud_palabras("Hola mundo esto es Python"))


# ============================================================
# KATA 13
# Función que, para un conjunto de caracteres, devuelva una
# lista de tuplas con cada letra en mayúsculas y minúsculas.
# Sin letras repetidas. Usa map().
# ============================================================

def mayusculas_minusculas(caracteres):
    # Usamos set() para eliminar duplicados antes de mapear
    sin_repetidos = set(caracteres)
    return list(map(lambda c: (c.upper(), c.lower()), sin_repetidos))

print("\n--- Kata 13 ---")
print(mayusculas_minusculas(["a", "B", "c", "a", "D", "b"]))


# ============================================================
# KATA 14
# Función que retorne las palabras de una lista que comiencen
# con una letra específica. Usa filter().
# ============================================================

def palabras_por_letra(lista, letra):
    return list(filter(lambda p: p.lower().startswith(letra.lower()), lista))

print("\n--- Kata 14 ---")
print(palabras_por_letra(["manzana", "pera", "mango", "uva", "melón"], "m"))


# ============================================================
# KATA 15
# Crea una función lambda que sume 3 a cada número de una lista.
# ============================================================

sumar_tres = lambda lista: list(map(lambda x: x + 3, lista))

print("\n--- Kata 15 ---")
print(sumar_tres([1, 2, 3, 4, 5]))


# ============================================================
# KATA 16
# Función que tome una cadena y un número n, y devuelva las
# palabras más largas que n. Usa filter().
# ============================================================

def palabras_mas_largas(cadena, n):
    palabras = cadena.split()
    return list(filter(lambda p: len(p) > n, palabras))

print("\n--- Kata 16 ---")
print(palabras_mas_largas("el rápido zorro marrón salta sobre el perro perezoso", 5))


# ============================================================
# KATA 17
# Función que tome una lista de dígitos y devuelva el número
# correspondiente. [5,7,2] → 572. Usa reduce().
# ============================================================

def digitos_a_numero(digitos):
    # Multiplicamos el acumulador por 10 y sumamos el siguiente dígito
    return reduce(lambda acc, d: acc * 10 + d, digitos)

print("\n--- Kata 17 ---")
print(digitos_a_numero([5, 7, 2]))
print(digitos_a_numero([1, 0, 0, 5]))


# ============================================================
# KATA 18
# Programa que cree una lista de diccionarios con info de
# estudiantes y use filter para extraer los de nota >= 90.
# ============================================================

estudiantes = [
    {"nombre": "Ana", "edad": 20, "calificacion": 95},
    {"nombre": "Luis", "edad": 22, "calificacion": 78},
    {"nombre": "María", "edad": 21, "calificacion": 91},
    {"nombre": "Pedro", "edad": 23, "calificacion": 65},
    {"nombre": "Sofía", "edad": 20, "calificacion": 88},
]

aprobados_con_honor = list(filter(lambda e: e["calificacion"] >= 90, estudiantes))

print("\n--- Kata 18 ---")
print(aprobados_con_honor)


# ============================================================
# KATA 19
# Crea una función lambda que filtre los números impares.
# ============================================================

filtrar_impares = lambda lista: list(filter(lambda x: x % 2 != 0, lista))

print("\n--- Kata 19 ---")
print(filtrar_impares([1, 2, 3, 4, 5, 6, 7, 8, 9]))


# ============================================================
# KATA 20
# Para una lista con elementos integer y string, obtén una
# nueva lista solo con los valores int. Usa filter().
# ============================================================

def solo_enteros(lista):
    return list(filter(lambda x: isinstance(x, int), lista))

print("\n--- Kata 20 ---")
print(solo_enteros([1, "hola", 3, "mundo", 5, 7, "bye"]))


# ============================================================
# KATA 21
# Crea una función que calcule el cubo de un número mediante
# una función lambda.
# ============================================================

cubo = lambda x: x ** 3

print("\n--- Kata 21 ---")
print(cubo(3))
print(cubo(5))


# ============================================================
# KATA 22
# Dada una lista numérica, obtén el producto total. Usa reduce().
# ============================================================

def producto_total(numeros):
    return reduce(lambda acc, x: acc * x, numeros)

print("\n--- Kata 22 ---")
print(producto_total([1, 2, 3, 4, 5]))


# ============================================================
# KATA 23
# Concatena una lista de palabras. Usa reduce().
# ============================================================

def concatenar_palabras(palabras):
    return reduce(lambda acc, p: acc + " " + p, palabras)

print("\n--- Kata 23 ---")
print(concatenar_palabras(["Hola", "mundo", "desde", "Python"]))


# ============================================================
# KATA 24
# Calcula la diferencia total de una lista. Usa reduce().
# ============================================================

def diferencia_total(numeros):
    return reduce(lambda acc, x: acc - x, numeros)

print("\n--- Kata 24 ---")
print(diferencia_total([100, 10, 5, 20]))


# ============================================================
# KATA 25
# Crea una función que cuente el número de caracteres en una
# cadena de texto.
# ============================================================

def contar_caracteres(cadena):
    return len(cadena)

print("\n--- Kata 25 ---")
print(contar_caracteres("Hola, mundo!"))


# ============================================================
# KATA 26
# Crea una función lambda que calcule el resto de la división
# entre dos números.
# ============================================================

resto_division = lambda a, b: a % b

print("\n--- Kata 26 ---")
print(resto_division(17, 5))


# ============================================================
# KATA 27
# Crea una función que calcule el promedio de una lista.
# ============================================================

def promedio(numeros):
    if len(numeros) == 0:
        return 0
    return sum(numeros) / len(numeros)

print("\n--- Kata 27 ---")
print(promedio([10, 20, 30, 40, 50]))


# ============================================================
# KATA 28
# Crea una función que busque y devuelva el primer elemento
# duplicado en una lista.
# ============================================================

def primer_duplicado(lista):
    vistos = set()
    for elemento in lista:
        if elemento in vistos:
            return elemento
        vistos.add(elemento)
    return None  # No hay duplicados

print("\n--- Kata 28 ---")
print(primer_duplicado([1, 2, 3, 4, 2, 5, 3]))
print(primer_duplicado([1, 2, 3]))


# ============================================================
# KATA 29
# Función que convierta una variable en string y enmascare
# todos los caracteres con '#' excepto los últimos 4.
# ============================================================

def enmascarar(valor):
    texto = str(valor)
    if len(texto) <= 4:
        return texto
    # Sustituimos todo menos los últimos 4 caracteres
    return "#" * (len(texto) - 4) + texto[-4:]

print("\n--- Kata 29 ---")
print(enmascarar(1234567890))
print(enmascarar("secreto123"))


# ============================================================
# KATA 30
# Función que determine si dos palabras son anagramas.
# ============================================================

def son_anagramas(palabra1, palabra2):
    # Ordenamos las letras de ambas palabras y comparamos
    return sorted(palabra1.lower()) == sorted(palabra2.lower())

print("\n--- Kata 30 ---")
print(son_anagramas("amor", "roma"))
print(son_anagramas("hola", "mundo"))


# ============================================================
# KATA 31
# Función que pida al usuario una lista de nombres y un nombre
# a buscar. Si no está, lanza una excepción.
# ============================================================

def buscar_nombre():
    nombres_input = input("Introduce nombres separados por comas: ")
    nombres = [n.strip() for n in nombres_input.split(",")]
    buscar = input("¿Qué nombre quieres buscar? ")
    if buscar in nombres:
        print(f"'{buscar}' fue encontrado en la lista.")
    else:
        raise ValueError(f"'{buscar}' no se encuentra en la lista.")

print("\n--- Kata 31 ---")
# buscar_nombre()  # Descomenta para ejecutar interactivamente


# ============================================================
# KATA 32
# Función que tome un nombre completo y una lista de empleados,
# busque el nombre y devuelva el puesto o un mensaje de error.
# ============================================================

def buscar_empleado(nombre, empleados):
    for empleado in empleados:
        if empleado["nombre"] == nombre:
            return empleado["puesto"]
    return "Esta persona no trabaja aquí."

print("\n--- Kata 32 ---")
empleados = [
    {"nombre": "Diego Couto", "puesto": "Desarrollador"},
    {"nombre": "Ana García", "puesto": "Diseñadora"},
    {"nombre": "Luis Martínez", "puesto": "Product Manager"},
]
print(buscar_empleado("Ana García", empleados))
print(buscar_empleado("John Doe", empleados))


# ============================================================
# KATA 33
# Función lambda que sume elementos correspondientes de dos
# listas. Usa map().
# ============================================================

sumar_listas = lambda l1, l2: list(map(lambda a, b: a + b, l1, l2))

print("\n--- Kata 33 ---")
print(sumar_listas([1, 2, 3], [10, 20, 30]))


# ============================================================
# KATA 34 - Clase Arbol
# Define un árbol genérico con tronco y ramas como atributos.
# Métodos: crecer_tronco, nueva_rama, crecer_ramas,
#          quitar_rama, info_arbol.
# ============================================================

class Arbol:
    def __init__(self):
        # Inicializamos el árbol con tronco de longitud 1 y sin ramas
        self.tronco = 1
        self.ramas = []

    def crecer_tronco(self):
        """Aumenta la longitud del tronco en una unidad."""
        self.tronco += 1

    def nueva_rama(self):
        """Añade una nueva rama de longitud 1."""
        self.ramas.append(1)

    def crecer_ramas(self):
        """Aumenta en 1 la longitud de todas las ramas existentes."""
        # Usamos list comprehension para crear una nueva lista con los valores actualizados
        self.ramas = [rama + 1 for rama in self.ramas]

    def quitar_rama(self, posicion):
        """Elimina la rama en la posición indicada."""
        if 0 <= posicion < len(self.ramas):
            self.ramas.pop(posicion)
        else:
            print(f"No existe rama en la posición {posicion}.")

    def info_arbol(self):
        """Devuelve información sobre el árbol."""
        return {
            "longitud_tronco": self.tronco,
            "numero_ramas": len(self.ramas),
            "longitudes_ramas": self.ramas
        }


print("\n--- Kata 34 - Clase Arbol ---")
# a. Crear un árbol
arbol = Arbol()

# b. Hacer crecer el tronco una unidad
arbol.crecer_tronco()

# c. Añadir una nueva rama
arbol.nueva_rama()

# d. Hacer crecer todas las ramas una unidad
arbol.crecer_ramas()

# e. Añadir dos nuevas ramas
arbol.nueva_rama()
arbol.nueva_rama()

# f. Retirar la rama en la posición 2
arbol.quitar_rama(2)

# g. Obtener información sobre el árbol
print(arbol.info_arbol())


# ============================================================
# KATA 35 - Clase UsuarioBanco
# Representa a un usuario de un banco con nombre, saldo y
# si tiene cuenta corriente.
# Métodos: retirar_dinero, transferir_dinero, agregar_dinero.
# ============================================================

class UsuarioBanco:
    def __init__(self, nombre, saldo, cuenta_corriente):
        self.nombre = nombre
        self.saldo = saldo
        self.cuenta_corriente = cuenta_corriente

    def agregar_dinero(self, cantidad):
        """Aumenta el saldo del usuario."""
        if cantidad <= 0:
            raise ValueError("La cantidad a agregar debe ser mayor que 0.")
        self.saldo += cantidad
        print(f"{self.nombre} ahora tiene {self.saldo} en su cuenta.")

    def retirar_dinero(self, cantidad):
        """Resta dinero del saldo. Lanza error si no hay saldo suficiente."""
        if cantidad <= 0:
            raise ValueError("La cantidad a retirar debe ser mayor que 0.")
        if cantidad > self.saldo:
            raise ValueError(f"{self.nombre} no tiene saldo suficiente.")
        self.saldo -= cantidad
        print(f"{self.nombre} retiró {cantidad}. Saldo actual: {self.saldo}")

    def transferir_dinero(self, otro_usuario, cantidad):
        """Transfiere dinero desde otro usuario a este usuario."""
        try:
            otro_usuario.retirar_dinero(cantidad)
            self.agregar_dinero(cantidad)
            print(f"Transferencia de {otro_usuario.nombre} a {self.nombre} completada.")
        except ValueError as e:
            print(f"Error en la transferencia: {e}")


print("\n--- Kata 35 - Clase UsuarioBanco ---")
# a. Crear dos usuarios
alicia = UsuarioBanco("Alicia", 100, True)
bob = UsuarioBanco("Bob", 50, True)

# b. Agregar 20 unidades al saldo de Bob
bob.agregar_dinero(20)

# c. Transferir 80 unidades de Bob a Alicia
alicia.transferir_dinero(bob, 80)

# d. Retirar 50 unidades del saldo de Alicia
alicia.retirar_dinero(50)


# ============================================================
# KATA 36 - procesar_texto
# Procesa un texto según la opción: contar, reemplazar, eliminar.
# ============================================================

def contar_palabras(texto):
    """Cuenta cuántas veces aparece cada palabra en el texto."""
    palabras = texto.lower().split()
    conteo = {}
    for palabra in palabras:
        conteo[palabra] = conteo.get(palabra, 0) + 1
    return conteo

def reemplazar_palabras(texto, palabra_original, palabra_nueva):
    """Sustituye una palabra por otra en el texto."""
    return texto.replace(palabra_original, palabra_nueva)

def eliminar_palabra(texto, palabra):
    """Elimina todas las apariciones de una palabra en el texto."""
    # Dividimos y filtramos la palabra, luego volvemos a unir
    return " ".join(w for w in texto.split() if w.lower() != palabra.lower())

def procesar_texto(texto, opcion, *args):
    """
    Procesa el texto según la opción indicada.
    - "contar": no necesita args extra.
    - "reemplazar": args = (palabra_original, palabra_nueva).
    - "eliminar": args = (palabra,).
    """
    if opcion == "contar":
        return contar_palabras(texto)
    elif opcion == "reemplazar":
        return reemplazar_palabras(texto, args[0], args[1])
    elif opcion == "eliminar":
        return eliminar_palabra(texto, args[0])
    else:
        raise ValueError(f"Opción '{opcion}' no reconocida.")

print("\n--- Kata 36 - procesar_texto ---")
texto_ejemplo = "el gato come el pescado y el gato duerme"
print(procesar_texto(texto_ejemplo, "contar"))
print(procesar_texto(texto_ejemplo, "reemplazar", "gato", "perro"))
print(procesar_texto(texto_ejemplo, "eliminar", "el"))


# ============================================================
# KATA 37
# Programa que indique si es de noche, día o tarde según
# la hora proporcionada por el usuario.
# ============================================================

def momento_del_dia(hora):
    """
    Determina si es de día, tarde o noche según la hora.
    Día: 6 - 13h / Tarde: 13 - 21h / Noche: 21 - 6h
    """
    if 6 <= hora < 13:
        return "Es de día ☀️"
    elif 13 <= hora < 21:
        return "Es de tarde 🌤️"
    else:
        return "Es de noche 🌙"

print("\n--- Kata 37 ---")
print(momento_del_dia(8))
print(momento_del_dia(15))
print(momento_del_dia(23))


# ============================================================
# KATA 38
# Programa que determine la calificación en texto según
# la nota numérica.
# 0-69: insuficiente / 70-79: bien / 80-89: muy bien / 90-100: excelente
# ============================================================

def calificacion_texto(nota):
    if 0 <= nota <= 69:
        return "Insuficiente"
    elif 70 <= nota <= 79:
        return "Bien"
    elif 80 <= nota <= 89:
        return "Muy bien"
    elif 90 <= nota <= 100:
        return "Excelente"
    else:
        return "Nota fuera de rango."

print("\n--- Kata 38 ---")
print(calificacion_texto(55))
print(calificacion_texto(75))
print(calificacion_texto(85))
print(calificacion_texto(95))


# ============================================================
# KATA 39
# Función que reciba una figura ("rectangulo", "circulo" o
# "triangulo") y una tupla con los datos necesarios para
# calcular el área.
# ============================================================

def calcular_area(figura, datos):
    """
    Calcula el área según la figura:
    - rectangulo: datos = (base, altura)
    - circulo: datos = (radio,)
    - triangulo: datos = (base, altura)
    """
    if figura == "rectangulo":
        base, altura = datos
        return base * altura
    elif figura == "circulo":
        radio = datos[0]
        return math.pi * radio ** 2
    elif figura == "triangulo":
        base, altura = datos
        return (base * altura) / 2
    else:
        raise ValueError(f"Figura '{figura}' no reconocida.")

print("\n--- Kata 39 ---")
print(f"Rectángulo: {calcular_area('rectangulo', (5, 3))}")
print(f"Círculo: {calcular_area('circulo', (4,)):.2f}")
print(f"Triángulo: {calcular_area('triangulo', (6, 4))}")


# ============================================================
# KATA 40
# Programa que calcule el precio final de una compra
# aplicando un cupón de descuento si el usuario tiene uno.
# ============================================================

def calcular_precio_final():
    try:
        precio = float(input("Introduce el precio original del artículo: "))
        if precio < 0:
            raise ValueError("El precio no puede ser negativo.")

        cupon = input("¿Tienes un cupón de descuento? (sí/no): ").strip().lower()

        if cupon == "sí" or cupon == "si":
            descuento = float(input("Introduce el valor del cupón de descuento: "))
            if descuento > 0:
                precio_final = precio - descuento
                # El precio final no puede ser negativo
                precio_final = max(0, precio_final)
                print(f"Descuento aplicado. Precio final: {precio_final:.2f}€")
            else:
                print("El cupón no es válido (debe ser mayor que 0).")
                print(f"Precio final sin descuento: {precio:.2f}€")
        elif cupon == "no":
            print(f"Precio final sin descuento: {precio:.2f}€")
        else:
            print("Respuesta no válida. Se muestra el precio sin descuento.")
            print(f"Precio final: {precio:.2f}€")

    except ValueError as e:
        print(f"Error: {e}")

print("\n--- Kata 40 ---")
# calcular_precio_final()  # Descomenta para ejecutar interactivamente
