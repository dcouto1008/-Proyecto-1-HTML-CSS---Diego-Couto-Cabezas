# Proyecto 3 - Katas Python

**Autor:** Diego Couto Cabezas  
**Asignatura:** The Power Education  

## Descripción

Repositorio con la resolución de las 40 katas de Python del Proyecto 3.  
Todos los ejercicios se encuentran en el archivo `katas.py`, cada uno encabezado con su enunciado en forma de comentario.

## Estructura

```
proyecto3-katas-python/
└── katas.py    # Los 40 ejercicios resueltos y comentados
```

## Cómo ejecutar

```bash
python katas.py
```

> Los ejercicios interactivos (katas 8, 11, 31 y 40) están comentados para no interrumpir la ejecución automática. Para probarlos, descomenta la llamada a la función correspondiente.

## Conceptos aplicados

- Tipos de datos básicos y funciones incorporadas (`len`, `sum`, `sorted`...)
- Estructuras de datos: listas, tuplas, diccionarios, sets
- Funciones de orden superior: `map()`, `filter()`, `reduce()`
- Funciones lambda
- Condicionales e iteración
- Recursividad
- Manejo de excepciones (`try / except`, excepciones personalizadas)
- Programación orientada a objetos (clases `Arbol` y `UsuarioBanco`)
- Módulos (`math`, `functools`)
