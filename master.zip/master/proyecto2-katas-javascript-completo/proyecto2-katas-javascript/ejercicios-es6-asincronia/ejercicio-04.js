// Ejercicio ES6 4 - .filter()

const ages = [22, 14, 24, 55, 65, 21, 12, 13, 90];

// 4.1 Valores mayores que 18
const olderThan18 = ages.filter(age => age > 18);
console.log(olderThan18);

// 4.2 Valores pares
const evenAges = ages.filter(age => age % 2 === 0);
console.log(evenAges);

const streamers = [
    { name: 'Rubius', age: 32, gameMorePlayed: 'Minecraft' },
    { name: 'Ibai', age: 25, gameMorePlayed: 'League of Legends' },
    { name: 'Reven', age: 43, gameMorePlayed: 'League of Legends' },
    { name: 'AuronPlay', age: 33, gameMorePlayed: 'Among Us' }
];

// 4.3 Streamers con gameMorePlayed = 'League of Legends'
const lolStreamers = streamers.filter(s => s.gameMorePlayed === 'League of Legends');
console.log(lolStreamers);

// 4.4 Streamers cuyo nombre incluya la letra 'u'
const uStreamers = streamers.filter(s => s.name.includes('u'));
console.log(uStreamers);

// 4.5 Streamers con 'Legends' en gameMorePlayed, poniendo gameMorePlayed en mayúsculas si age > 35
const legendsStreamers = streamers
    .filter(s => s.gameMorePlayed.includes('Legends'))
    .map(s => {
        if (s.age > 35) {
            return { ...s, gameMorePlayed: s.gameMorePlayed.toUpperCase() };
        }
        return s;
    });
console.log(legendsStreamers);
