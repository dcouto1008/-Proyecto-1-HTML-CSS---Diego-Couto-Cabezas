// Ejercicio ES6 3 - .map()

const users = [
    { id: 1, name: 'Abel' },
    { id: 2, name: 'Julia' },
    { id: 3, name: 'Pedro' },
    { id: 4, name: 'Amanda' }
];

// 3.1 Array con solo los nombres
const names = users.map(user => user.name);
console.log(names);

// 3.2 Array de nombres, cambiando a 'Anacleto' si empieza por 'A'
const namesUpdated = users.map(user => {
    if (user.name.startsWith('A')) {
        return 'Anacleto';
    }
    return user.name;
});
console.log(namesUpdated);

// 3.3 Array de nombres añadiendo ' (Visitado)' si isVisited = true
const cities = [
    { isVisited: true, name: 'Tokyo' },
    { isVisited: false, name: 'Madagascar' },
    { isVisited: true, name: 'Amsterdam' },
    { isVisited: false, name: 'Seul' }
];

const citiesLabeled = cities.map(city => {
    if (city.isVisited) {
        return city.name + ' (Visitado)';
    }
    return city.name;
});
console.log(citiesLabeled);
