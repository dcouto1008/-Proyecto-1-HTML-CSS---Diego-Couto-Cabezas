// Ejercicio ES6 9 - PokeAPI Pokémon aleatorio

const img = document.querySelector('.random-image');
const nameLabel = document.getElementById('pokemon-name');
const btn = document.getElementById('btn-reload');

function loadRandomPokemon() {
    const randomId = Math.floor(Math.random() * 151) + 1;

    fetch('https://pokeapi.co/api/v2/pokemon/' + randomId)
        .then(response => response.json())
        .then(pokemon => {
            img.src = pokemon.sprites.other['official-artwork'].front_default;
            img.alt = pokemon.name;
            nameLabel.textContent = pokemon.name;
        })
        .catch(error => console.error('Error al cargar el Pokémon:', error));
}

// Carga al entrar en la página
loadRandomPokemon();

// Botón para cargar otro
btn.addEventListener('click', loadRandomPokemon);
