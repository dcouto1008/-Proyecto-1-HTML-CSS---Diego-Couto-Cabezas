// Ejercicio ES6 2 - Spread Operators

// 2.1 Copia de array con spread
const pointsList = [32, 54, 21, 64, 75, 43];
const pointsListCopy = [...pointsList];
console.log(pointsListCopy);

// 2.2 Copia de objeto con spread
const toy = { name: 'Bus laiyiar', date: '20-30-1995', color: 'multicolor' };
const toyCopy = { ...toy };
console.log(toyCopy);

// 2.3 Unir dos arrays con spread
const pointsList2 = [54, 87, 99, 65, 32];
const mergedPoints = [...pointsList, ...pointsList2];
console.log(mergedPoints);

// 2.4 Fusionar dos objetos con spread
const toyUpdate = { lights: 'rgb', power: ['Volar like a dragon', 'MoonWalk'] };
const mergedToy = { ...toy, ...toyUpdate };
console.log(mergedToy);

// 2.5 Copia del array eliminando la posición 2 sin modificar el original
const colors = ['rojo', 'azul', 'amarillo', 'verde', 'naranja'];
const colorsCopy = [...colors.slice(0, 2), ...colors.slice(3)];
console.log(colorsCopy);
console.log(colors); // El original sigue intacto
