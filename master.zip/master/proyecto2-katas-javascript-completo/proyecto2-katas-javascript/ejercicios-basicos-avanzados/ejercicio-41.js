// Ejercicio 41

function rollDice(faces) {
  return Math.floor(Math.random() * faces) + 1;
}

console.log(rollDice(6));   // Dado de 6 caras
console.log(rollDice(20));  // Dado de 20 caras
console.log(rollDice(100)); // Dado de 100 caras
