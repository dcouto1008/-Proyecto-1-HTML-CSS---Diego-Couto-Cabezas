// Ejercicio 4

const aldeanos = ["Fibrilio", "Narciso", "Vacarena", "Tendo", "Nendo"];

// 4.1 Saca a "Tendo" por consola atacando su posición
console.log(aldeanos[3]);

// 4.2 Coloca en el último lugar a "Cervasio"
aldeanos.push("Cervasio");
console.log(aldeanos);

// 4.3 Cambia el primer elemento por "Bambina"
aldeanos[0] = "Bambina";
console.log(aldeanos);

// 4.4 Dale la vuelta al array
aldeanos.reverse();
console.log(aldeanos);

// 4.5 Cambia "Narciso" por "Canela" usando un método de array
const indexNarciso = aldeanos.indexOf("Narciso");
aldeanos.splice(indexNarciso, 1, "Canela");
console.log(aldeanos);

// 4.6 Imprime el último elemento sin atacar la posición explícitamente
console.log(aldeanos[aldeanos.length - 1]);
