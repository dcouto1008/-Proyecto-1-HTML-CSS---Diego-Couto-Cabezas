// Ejercicio 3

// 3.1 Multiplica 10 por 5
console.log(10 * 5);

// 3.2 Divide 10 por 2
console.log(10 / 2);

// 3.3 Resto de dividir 15 por 9
console.log(15 % 9);

// 3.4 o = 15, con p = 10 y j = 5
let p = 10;
let j = 5;
let o = p;
o += j;
console.log(o); // 15

// 3.5 i = 50, con c = 10 y m = 5
let c = 10;
let m = 5;
let i = c;
i *= m;
console.log(i); // 50
