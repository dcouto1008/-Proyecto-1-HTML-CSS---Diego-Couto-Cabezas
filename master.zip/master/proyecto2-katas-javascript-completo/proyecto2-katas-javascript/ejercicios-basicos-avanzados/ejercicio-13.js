// Ejercicio 13

const names = [
  "Peter",
  "Steve",
  "Tony",
  "Natasha",
  "Clint",
  "Logan",
  "Xabier",
  "Bruce",
  "Peggy",
  "Jessica",
  "Marc",
];

function nameFinder(nameList, value) {
  for (let i = 0; i < nameList.length; i++) {
    if (nameList[i] === value) {
      console.log(true, i);
      return;
    }
  }
  console.log(false);
}

nameFinder(names, "Tony");
nameFinder(names, "Wolverine");
