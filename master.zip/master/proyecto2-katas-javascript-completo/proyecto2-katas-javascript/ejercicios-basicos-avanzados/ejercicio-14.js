// Ejercicio 14

const words = [
  "code",
  "repeat",
  "eat",
  "sleep",
  "code",
  "enjoy",
  "sleep",
  "code",
  "enjoy",
  "sleep",
  "code",
];

function repeatCounter(list) {
  const counter = {};
  for (let i = 0; i < list.length; i++) {
    if (counter[list[i]]) {
      counter[list[i]]++;
    } else {
      counter[list[i]] = 1;
    }
  }
  return counter;
}

console.log(repeatCounter(words));
