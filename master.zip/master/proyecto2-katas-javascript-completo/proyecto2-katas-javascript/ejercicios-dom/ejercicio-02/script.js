// Ejercicio DOM 2

// 2.1 Insertar un div vacío
const div1 = document.createElement('div');
document.body.appendChild(div1);

// 2.2 Insertar un div que contenga un p
const div2 = document.createElement('div');
const p2 = document.createElement('p');
p2.textContent = 'Soy un párrafo dentro de un div';
div2.appendChild(p2);
document.body.appendChild(div2);

// 2.3 Insertar un div con 6 p usando un loop
const div3 = document.createElement('div');
for (let i = 1; i <= 6; i++) {
    const p = document.createElement('p');
    p.textContent = 'Párrafo número ' + i;
    div3.appendChild(p);
}
document.body.appendChild(div3);

// 2.4 Insertar una p con el texto 'Soy dinámico!'
const pDinamico = document.createElement('p');
pDinamico.textContent = 'Soy dinámico!';
document.body.appendChild(pDinamico);

// 2.5 Insertar texto en el h2 con clase .fn-insert-here
const h2 = document.querySelector('h2.fn-insert-here');
h2.textContent = 'Wubba Lubba dub dub';

// 2.6 Crear lista ul > li con el array apps
const apps = ['Facebook', 'Netflix', 'Instagram', 'Snapchat', 'Twitter'];
const ul = document.createElement('ul');
for (const app of apps) {
    const li = document.createElement('li');
    li.textContent = app;
    ul.appendChild(li);
}
document.body.appendChild(ul);

// 2.7 Eliminar todos los nodos con clase .fn-remove-me
const elemsToRemove = document.querySelectorAll('.fn-remove-me');
elemsToRemove.forEach(elem => elem.remove());

// 2.8 Insertar una p con 'Voy en medio!' entre los dos div (sin clase)
const allDivs = document.querySelectorAll('div:not([class])');
const pMedio = document.createElement('p');
pMedio.textContent = 'Voy en medio!';
allDivs[0].insertAdjacentElement('afterend', pMedio);

// 2.9 Insertar p con 'Voy dentro!' en cada div con clase .fn-insert-here
const insertHereDivs = document.querySelectorAll('.fn-insert-here');
insertHereDivs.forEach(div => {
    const p = document.createElement('p');
    p.textContent = 'Voy dentro!';
    div.appendChild(p);
});
