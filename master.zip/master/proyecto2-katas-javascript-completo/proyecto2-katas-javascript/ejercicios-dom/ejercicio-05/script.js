// Ejercicio DOM 5

const albums = [
    "De Mysteriis Dom Sathanas",
    "Reign of Blood",
    "Ride the Lightning",
    "Painkiller",
    "Iron Fist",
];

const ul = document.getElementById('album-list');

albums.forEach((album, index) => {
    const li = document.createElement('li');

    const span = document.createElement('span');
    span.className = 'album-number';
    span.textContent = index + 1;

    li.appendChild(span);
    li.appendChild(document.createTextNode(album));
    ul.appendChild(li);
});
